using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    [Header("Health Info")]
    public int maxHealth = 100;
    public int currentHealth;
    public Image healthBar;

    [Header("Death Info")]
    public bool isDead = false;
    public GameManager gameManager;

    private void Start()
    {
        currentHealth = maxHealth;
        isDead = false;
    }

    public void TakeDamage(int damage)
    {
        if (isDead)
            return;

        currentHealth -= damage;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);

        healthBar.fillAmount = (float)currentHealth / maxHealth;

        currentHealth = Mathf.Max(currentHealth, 0);

        Debug.Log( "Player took " + damage + " damage! HP: " + currentHealth + "/" + maxHealth);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public void Heal(int amount)
    {
        if (isDead)
            return;

        currentHealth += amount;

        currentHealth = Mathf.Min(currentHealth, maxHealth);

        Debug.Log("Player healed! HP: " + currentHealth + "/" + maxHealth);
    }

    private void Die()
    {
        if (isDead)
            return;

        isDead = true;
        if (gameManager != null)
        {
            gameManager.GameOver();
        }
    }

    public void ResetHealth()
    {
        currentHealth = maxHealth;
        isDead = false;
    }
}