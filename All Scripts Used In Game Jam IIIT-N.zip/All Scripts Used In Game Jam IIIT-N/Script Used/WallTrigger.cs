using UnityEngine;

public class WallTrigger : MonoBehaviour
{
    public GameObject wallCrosstxt;
    public GameObject tipBar;
    
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            wallCrosstxt.SetActive(true);
            tipBar.SetActive(false);
        }
    }
}
