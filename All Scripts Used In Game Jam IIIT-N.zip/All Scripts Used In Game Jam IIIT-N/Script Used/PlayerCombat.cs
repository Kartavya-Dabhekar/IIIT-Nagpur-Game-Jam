using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;

public class PlayerCombat : MonoBehaviour
{
    [Header("References")]
    public Animator animator;
    public PlayerController leonController;
    public AudioSource audioSource;
    public AudioClip attackSFX;

    [Header("Attack Points")]
    public Transform rightHandAttackPoint;
    public Transform leftHandAttackPoint;
    public Transform kickAttackPoint;

    [Header("Attack Settings")]
    public float attackRange = 1.2f;

    public int punchDamage = 20;
    public int kickDamage = 35;

    [Header("Attack Timing")]
    public float comboResetTime = 0.8f;

    [Header("Enemy Detection")]
    public LayerMask enemyLayer;

    [Header("Combat Layer")]
    public string combatLayerName = "Combat Layer";
    public float combatLayerWeight = 1f;

    [Header("Conditions")]
    public bool cantMoveOnCombat;

    private CharacterController characterController;

    private int combatLayerIndex = -1;

    private int comboStep = 0;

    private int attackQueue = 0;

    private bool isAttacking = false;

    private bool isHoldingAttack = false;

    private float lastAttackInputTime;

    private HashSet<EnemyHealth> damagedEnemies = new HashSet<EnemyHealth>(); 

    private void Start()
    {
        combatLayerIndex = animator.GetLayerIndex(combatLayerName);

        if (combatLayerIndex == -1)
        {
            Debug.LogError("PlayerCombat: Combat Layer '" + combatLayerName + "' was not found!");
        }

        characterController = GetComponentInParent<CharacterController>();

        SetCombatLayer(false);
    }

    private void Update()
    {
    
        HandleCombatInput();

        if (!isHoldingAttack &&
            !isAttacking &&
            Time.time - lastAttackInputTime > comboResetTime)
        {
            comboStep = 0;
            attackQueue = 0;
        }
    }

    private void HandleCombatInput()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame && characterController.isGrounded)
        {
            cantMoveOnCombat = true;
            Invoke("EnableInput", 1f);

            //leonController.enabled = false;

            isHoldingAttack = true;

            lastAttackInputTime = Time.time;

            QueueAttack();
        }

        if (Mouse.current.leftButton.isPressed && characterController.isGrounded)
        {
            cantMoveOnCombat = true;
            Invoke("EnableInput", 1f);
            isHoldingAttack = true;
        }

        if (Mouse.current.leftButton.wasReleasedThisFrame && characterController.isGrounded)
        {
            cantMoveOnCombat = true;
            Invoke("EnableInput", 1f);
            isHoldingAttack = false;
        }
    }

    private void EnableInput()
    {
        cantMoveOnCombat = false;
    }

    private void QueueAttack()
    {
        lastAttackInputTime = Time.time;

        if (attackQueue < 3)
        {
            attackQueue++;
        }

        if (!isAttacking)
        {
            StartNextAttack();
        }
    }

    private void StartNextAttack()
    {
        if (attackQueue <= 0)
        {
            isAttacking = false;
            SetCombatLayer(false);
            return;
        }

        isAttacking = true;
        SetCombatLayer(true);
        attackQueue--;

        comboStep++;

        if (comboStep == 1)
        {
            damagedEnemies.Clear();
            animator.SetTrigger("Punch");
            Debug.Log("Combat: Punch 1");
        }

        else if (comboStep == 2)
        {
            damagedEnemies.Clear();
            animator.SetTrigger("Punch2");
            Debug.Log("Combat: Punch 2");
        }

        else if (comboStep == 3)
        {
            damagedEnemies.Clear();
            animator.SetTrigger("Kick");
            Debug.Log("Combat: Kick");
            comboStep = 0;
        }
    }

    public void RightPunchHit()
    {
        Debug.Log("Combat: Right Punch Hit");
        audioSource.PlayOneShot(attackSFX);
        DealDamage(punchDamage, rightHandAttackPoint);
    }

    public void LeftPunchHit()
    {
        Debug.Log("Combat: Left Punch Hit");
        audioSource.PlayOneShot(attackSFX);
        DealDamage(punchDamage, leftHandAttackPoint);
    }

    public void KickHit()
    {
        Debug.Log("Combat: Kick Hit");
        audioSource.PlayOneShot(attackSFX);
        DealDamage(kickDamage, kickAttackPoint);
    }

    public void AttackAnimationFinished()
    {
        isAttacking = false;

        if (isHoldingAttack)
        {
            attackQueue++;

            if (attackQueue > 3)
            {
                attackQueue = 3;
            }

            StartNextAttack();

            return;
        }

        if (attackQueue > 0)
        {
            StartNextAttack();

            return;
        }

        comboStep = 0;
        SetCombatLayer(false);

        if (leonController != null)
        {
            leonController.enabled = true;
        }

        Debug.Log("Combat: Combo Finished");
    }


    private void DealDamage(int damage, Transform currentAttackPoint)
    {
        Collider[] colliders = Physics.OverlapSphere(currentAttackPoint.position, attackRange, enemyLayer);

        foreach (Collider enemyCollider in colliders)
        {
            EnemyHealth health = enemyCollider.GetComponentInParent<EnemyHealth>();

            if (damagedEnemies.Contains(health))
                continue;

            damagedEnemies.Add(health);

            Vector3 attackDirection = (health.transform.position - transform.position).normalized;
            health.TakeDamage( damage, true, attackDirection);

        }
    }

    private void SetCombatLayer(bool active)
    {
        if (combatLayerIndex == -1)
            return;

        float targetWeight = active ? combatLayerWeight : 0f;
        animator.SetLayerWeight( combatLayerIndex, targetWeight);
    }
}