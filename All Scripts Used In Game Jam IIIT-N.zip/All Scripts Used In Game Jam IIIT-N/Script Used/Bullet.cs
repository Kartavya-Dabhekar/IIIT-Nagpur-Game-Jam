using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float Speed = 10f;
    public int damage = 10;

    private Rigidbody rb;
    private Vector3 direction;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    public void SetDirection(Vector3 newDirection)
    {
        direction = newDirection.normalized;
    }

    void Start()
    {
        rb.linearVelocity = direction * Speed;
    }

    void OnCollisionEnter(Collision collision)
    {
        var enemyHealyh = collision.gameObject.GetComponent<EnemyHealth>();
        if (enemyHealyh != null)
        {
            enemyHealyh.TakeDamage(damage);
        }

        Destroy(gameObject);
    }
}
