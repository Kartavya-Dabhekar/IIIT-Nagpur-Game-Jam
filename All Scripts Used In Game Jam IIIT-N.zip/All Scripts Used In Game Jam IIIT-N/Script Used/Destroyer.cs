using UnityEngine;

public class Destroyer : MonoBehaviour
{
    void OnCollisionEnter(Collision collision)
    {
        PlayerHealth playerHealth = collision.gameObject.GetComponent<PlayerHealth>();

        if (playerHealth != null)
        {
            playerHealth.TakeDamage(10);
        }

        Destroy(this.gameObject, 1f);
    }
}
