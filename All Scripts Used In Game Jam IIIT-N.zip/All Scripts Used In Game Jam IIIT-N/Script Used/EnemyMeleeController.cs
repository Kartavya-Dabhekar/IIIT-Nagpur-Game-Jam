using UnityEngine;
using UnityEngine.AI;

public class EnemyMeleeController : MonoBehaviour
{
    [Header("Patrol Info")]
    [SerializeField] private Transform[] wayPoints;
    [SerializeField] private float waitTime = 2f;

    [Header("Detection Info")]
    [SerializeField] private float detectionRange = 210f;
    [SerializeField] private float attackRange = 2f;

    [Header("Attack Info")]
    [SerializeField] private float timeBetweenAttacks = 1.5f;
    [SerializeField] private int attackDamage = 10;
    [SerializeField] private float damageRange = 1.2f;
    [SerializeField] private Transform attackPoint;

    [Header("Layers Info")]
    public LayerMask whatIsPlayer;

    [Header("Player Info")]
    public Transform player;
    public Transform detectionPoint;

    public bool canDetect;
    public bool canAttack;

    private int currentWaypoint = 0;
    private float waitTimer = 0;
    private bool movingForward = true;
    private bool alreadyAttacked;
    private bool returningToPatrol;

    private NavMeshAgent agent;
    private Animator animator;

    private void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();

        if (wayPoints.Length > 0)
        {
            agent.SetDestination(wayPoints[currentWaypoint].position);
        }
    }

    private void Update()
    {
        canDetect = Physics.CheckSphere(detectionPoint.position, detectionRange, whatIsPlayer);

        canAttack = Physics.CheckSphere(detectionPoint.position, attackRange, whatIsPlayer);

        if (canAttack)
        {
            AttackPlayer();
        }
        else if (canDetect)
        {
            ChasePlayer();
        }
        else
        {
            Patrolling();
        }
    }

    private void Patrolling()
    {
        agent.isStopped = false;

        if (!returningToPatrol)
        {
            returningToPatrol = true;

            agent.SetDestination(wayPoints[currentWaypoint].position);
        }

        if (!agent.pathPending && agent.remainingDistance < 0.5f)
        {
            waitTimer += Time.deltaTime;

            if (waitTimer > waitTime)
            {
                waitTimer = 0;
                GoToNextWaypoint();
            }
        }

        animator.SetFloat("Speed", agent.velocity.magnitude);
    }

    private void ChasePlayer()
    {
        returningToPatrol = false;

        agent.isStopped = false;

        agent.SetDestination(player.position);

        animator.SetFloat("Speed", agent.velocity.magnitude);
    }

    private void AttackPlayer()
    {
        returningToPatrol = false;

        agent.isStopped = true;
        agent.velocity = Vector3.zero;

        Vector3 direction = player.position - transform.position;

        direction.y = 0f;

        if (direction != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(direction);
        }

        if (!alreadyAttacked)
        {
            alreadyAttacked = true;

            animator.ResetTrigger("Attack");
            animator.SetTrigger("Attack");

            Invoke(nameof(ResetAttack), timeBetweenAttacks);
        }
    }

    public void AttackHit()
    {
        Collider[] hits = Physics.OverlapSphere(attackPoint.position, damageRange, whatIsPlayer);

        foreach (Collider hit in hits)
        {
            PlayerHealth playerHealth = hit.GetComponentInParent<PlayerHealth>();
            playerHealth.TakeDamage(attackDamage);
        }
    }

    private void ResetAttack()
    {
        alreadyAttacked = false;
    }

    private void GoToNextWaypoint()
    {
        if (movingForward)
        {
            currentWaypoint++;

            if (currentWaypoint >= wayPoints.Length)
            {
                currentWaypoint = wayPoints.Length - 2;

                movingForward = false;
            }
        }
        else
        {
            currentWaypoint--;

            if (currentWaypoint < 0)
            {
                currentWaypoint = 1;
                movingForward = true;
            }
        }

        agent.SetDestination(wayPoints[currentWaypoint].position);
    }
}