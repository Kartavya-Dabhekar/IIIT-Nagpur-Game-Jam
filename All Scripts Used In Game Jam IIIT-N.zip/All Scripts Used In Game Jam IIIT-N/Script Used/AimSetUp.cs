using Unity.Cinemachine;
using UnityEngine;
using TMPro;
using System.Collections;
using UnityEngine.InputSystem;
using UnityEngine.Animations.Rigging;

public class AimSetUp : MonoBehaviour
{
    public PlayerInputs leonInputs;
    public LayerMask aimMask;
    public Transform debug;
    public Transform spawnBulletPosition;
    public GameObject bulletPrefab;
    public GameObject muzzleFlashPrefab;
    public PlayerController leonController;
    public TwoBoneIKConstraint twoBoneIKConstraint;
    public AudioSource audioSource;
    public AudioClip pistolSFX;

    [SerializeField] private CinemachineThirdPersonFollow aimCam;

    [Header("Ammo Info")]
    public int magazineSize = 30;
    public int currentAmmo = 30;
    public int reserveAmmo = 120;

    [Header("Fire Info")]
    public float fireRate = 0.5f;

    [Header("Reload Info")]
    public float reloadTime = 2f;

    [Header("UI Info")]
    public TMP_Text ammoText;

    private float nextFireTime = 0f;
    private bool isReloading = false;

    void Start()
    {
        currentAmmo = magazineSize;
        UpdateAmmoUI();
    }

    void Update()
    {
        aimCam.gameObject.SetActive(leonInputs.aimToggleOn);

        UpdateAmmoUI();

        if (isReloading)
            return;

        if (Keyboard.current.rKey.wasPressedThisFrame)
        {
            if (currentAmmo < magazineSize && reserveAmmo > 0)
            {
                StartCoroutine(Reload());
                return;
            }
        }

        if (currentAmmo <= 0 && reserveAmmo > 0)
        {
            StartCoroutine(Reload());
            return;
        }

        Vector2 screenCenter = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);
        Ray ray = Camera.main.ScreenPointToRay(screenCenter);
        Vector3 aimPoint;

        if (Physics.Raycast(ray, out RaycastHit hit, 999f, aimMask))
        {
            aimPoint = hit.point;
            debug.position = aimPoint;
        }
        else
        {
            aimPoint = ray.origin + ray.direction * 999f;
        }

        if (leonInputs.attackPressed && Time.time >= nextFireTime && !leonController.playerIsSprinting &&
            currentAmmo > 0 && twoBoneIKConstraint.weight >= .95f)
        {
            Fire(aimPoint);
        }
    }

    void Fire(Vector3 aimPoint)
    {
        Debug.Log("fire!");
        nextFireTime = Time.time + fireRate;

        Vector3 direction = (aimPoint - spawnBulletPosition.position).normalized;

        GameObject bullet = Instantiate(bulletPrefab, spawnBulletPosition.position, Quaternion.LookRotation(direction));
        Bullet bulletScript = bullet.GetComponent<Bullet>();


        if (bulletScript != null)
        {
            
            bulletScript.SetDirection(direction);

            currentAmmo--;

            if (muzzleFlashPrefab != null)
            {
                GameObject flash = Instantiate(muzzleFlashPrefab, spawnBulletPosition.position, spawnBulletPosition.rotation);
                Destroy(flash, 0.1f);
            }

            if (audioSource != null && pistolSFX != null)
            {
                audioSource.PlayOneShot(pistolSFX);
            }

            UpdateAmmoUI();
        }
        else
        {
            Destroy(bullet);
        }
    }

    IEnumerator Reload()
    {
        isReloading = true;

        Debug.Log("Pistolz Reloading...");

        yield return new WaitForSeconds(reloadTime);

        int ammoNeeded = magazineSize - currentAmmo;

        int ammoToLoad = Mathf.Min(ammoNeeded, reserveAmmo);

        currentAmmo += ammoToLoad;
        reserveAmmo -= ammoToLoad;

        isReloading = false;

        UpdateAmmoUI();
    }

    void UpdateAmmoUI()
    {
        if (ammoText != null)
        {
            ammoText.text = currentAmmo + " / " + reserveAmmo;
        }
    }
}