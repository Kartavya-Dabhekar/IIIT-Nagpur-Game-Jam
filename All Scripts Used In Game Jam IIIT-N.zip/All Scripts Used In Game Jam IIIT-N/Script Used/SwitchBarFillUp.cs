using UnityEngine;
using UnityEngine.UI;

public class SwitchBarFillUp : MonoBehaviour
{
    [Header("UI Info")]
    [SerializeField] private Image fillImage;

    [Header("Time Fill")]
    [SerializeField] private float timeToFull = 75f;

    [Header("Transformation Info")]
    [SerializeField] private bool isTransformed = false;

    private float currentFill = 0f;

    private void Start()
    {
        currentFill = 0f;
        UpdateBar();
    }

    private void Update()
    {
        if (currentFill >= 1f)
            return;

        currentFill += Time.deltaTime / timeToFull;
        currentFill = Mathf.Clamp01(currentFill);

        UpdateBar();
    }

    public void StartTransformation()
    {
        isTransformed = true;
    }

    public void EndTransformation()
    {
        isTransformed = false;
        currentFill = 0f;

        UpdateBar();
    }

    private void UpdateBar()
    {
        fillImage.fillAmount = currentFill;
    }

    public float GetCurrentFill()
    {
        return currentFill;
    }

    public bool IsFull()
    {
        return currentFill >= 1f;
    }

    public bool IsTransformed()
    {
        return isTransformed;
    }

    public void ResetBar()
    {
        currentFill = 0f;

        UpdateBar();
    }
}