using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [Header("UI Info")]
    public GameObject miniMap;
    public GameObject miniMapRec;
    public GameObject pauseBar;
    public GameObject gameOverBar;

    [Header("Game State")]
    public bool activeMap;
    public bool pauseGame;
    public bool gameOver;

    void Start()
    {
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;

        Time.timeScale = 1f;
        gameOverBar.SetActive(false);
    }

    void Update()
    {
        if (gameOver)
            return;

        if (Keyboard.current.mKey.wasPressedThisFrame && !activeMap)
        {
            activeMap = true;

            miniMap.SetActive(false);
            miniMapRec.SetActive(false);
        }
        else if (Keyboard.current.mKey.wasPressedThisFrame && activeMap)
        {
            activeMap = false;

            miniMap.SetActive(true);
            miniMapRec.SetActive(true);
        }

        if (Keyboard.current.escapeKey.wasPressedThisFrame)
        {
            pauseGame = !pauseGame;

            if (pauseGame)
            {
                pauseBar.SetActive(true);
                Time.timeScale = 0f;

                Cursor.visible = true;
                Cursor.lockState = CursorLockMode.None;
            }
            else
            {
                pauseBar.SetActive(false);
                Time.timeScale = 1f;

                Cursor.visible = false;
                Cursor.lockState = CursorLockMode.Locked;
            }
        }
    }

    public void GameOver()
    {
        if (gameOver)
            return;

        gameOver = true;

        Time.timeScale = 0f;

        if (gameOverBar != null)
            gameOverBar.SetActive(true);

        if (pauseBar != null)
            pauseBar.SetActive(false);

        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;

        Debug.Log("GAME OVER");
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;

        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;

        SceneManager.LoadScene("Prototyping");
    }

    public void MainMenu()
    {
        Time.timeScale = 1f;

        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;

        SceneManager.LoadScene("Main Menu");
    }

    public void QuitGame()
    {
        Time.timeScale = 1f;

        Debug.Log("Game over!");

        Application.Quit();
    }
}