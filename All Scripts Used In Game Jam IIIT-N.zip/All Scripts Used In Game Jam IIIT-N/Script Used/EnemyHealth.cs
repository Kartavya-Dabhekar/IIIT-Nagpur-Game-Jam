using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class EnemyHealth : MonoBehaviour
{
    [Header("Health Info")]
    public int maxHealth = 100;
    public int currentHealth;

    [Header("Health Bar")]
    [SerializeField] private Image healthBarFill;

    [Header("References")]
    public NavMeshAgent agent;
    public EnemyRagdoll enemyRagdoll1;
    public Animator animator;
    public CharacterController characterController;

    [Header("References")]
    public EnemyRange enemyRange;
    public EnemyMeleeController enemyMeleeController;

    private bool isDead = false;

    private void Start()
    {
        currentHealth = maxHealth;

        UpdateHealthBar();
    }

    public void TakeDamage(int damage)
    {
        TakeDamage(damage, false, Vector3.zero);
    }

    public void TakeDamage(int damage, bool useKnockback, Vector3 attackDirection)
    {
        currentHealth -= damage;

        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);

        UpdateHealthBar();

        if (currentHealth <= 0)
        {
            agent.isStopped = true;
            Die(useKnockback, attackDirection);
        }
    }

    private void UpdateHealthBar()
    {

        healthBarFill.fillAmount = (float)currentHealth / maxHealth;
    }

    private void Die(bool useKnockback, Vector3 attackDirection)
    {
        isDead = true;

        animator.enabled = false;
        characterController.enabled = false;

        enemyMeleeController.enabled = false;
        enemyRange.enabled = false;
        enemyRagdoll1.ActivateRagdoll(useKnockback, attackDirection);

    }
}
