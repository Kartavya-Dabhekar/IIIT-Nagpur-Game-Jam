using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private CharacterController characterController;
    [SerializeField] private Camera cam;
    public float rotationTolerance = 90f;
    public float jumpVel = 4f;

    public float RotationMismatch { get; private set;} = 0f;
    public bool IsRotatingToTarget { get; private set; } = false;
    
    public Vector3 finalVel;
    public bool playerIsSprinting;

    [Header("Player Info")]
    public float runAcceleration = 30f;
    public float runSpeed = 6f;
    public float sprintAccleration = 60f;
    public float sprintSpeed = 12f;
    public float drag = 8f;
    public float gravity = -9.81f;
    public float jumpForce = 4f;
    public float movingThreshlod = 0.01f;
    public float verticleRecoil = 0.5f;

    [Header("Camera Info")]
    public float lookSenH = 0.1f;
    public float lookSenV = 0.1f;
    public float lookMaxLimitV = 89f;
    public float lookMinLimitV = 89f;

    [Header("Animation Data")]
    public float playerModelRotationSpeed = 10f;
    public float rotationTargetTime = 0.25f;

    [Header("Envirnmental Details")]
    [SerializeField] private LayerMask groundLayer;
    public PlayerCombat playerCombat;

    [Header("Audio Info")]
    [SerializeField] private AudioClip walkAudio;
    [SerializeField] private AudioClip runAudio;
    [SerializeField] private AudioSource audioSource;

    [SerializeField] private float walkStepInterval = 0.5f;
    [SerializeField] private float runStepInterval = 0.3f;

    private float footstepTimer;

    private float verticalVelocity;
    private Vector3 horizontalVelocity;
    private float rotatingToTargetTime = 0f;
    private float antiBug;
    private bool isRoatingClockWise;

    private PlayerInputs leonInputs;
    private PlayerState leonState;
    private Vector3 cameraRotation = Vector3.zero;
    private Vector3 playerTargetRotation = Vector3.zero;

    private void Awake()
    {
        leonInputs = GetComponent<PlayerInputs>();
        leonState = GetComponent<PlayerState>();
        antiBug = sprintSpeed;

        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;
    }

    private void Update()
    {
        if (!playerCombat.cantMoveOnCombat)
        {
            UpdateMovementState();
            HandleVerticalMovement();
            HandleLateralMovement();
            HandleFootsteps();
        } 
    }

    private void HandleVerticalMovement()
    {
        bool isGrounded = leonState.InGroundedState();

        if (leonInputs.jumpPressed && isGrounded)
        {
            verticalVelocity += jumpVel + Mathf.Sqrt(jumpForce * -3 * gravity);
        }
    }

    private void UpdateMovementState()
    {
        bool isMovementInput = leonInputs.MovementInput != Vector2.zero;
        bool isMovingLaterally = IsMovingLaterally();
        bool isSprinting = leonInputs.sprintToggleOn && isMovingLaterally;

        PlayerMovementState playerMovementState =   isSprinting ? PlayerMovementState.Sprinting :
                                                    isMovementInput || isMovingLaterally ? PlayerMovementState.Running : PlayerMovementState.Idling;
        leonState.SetPlayerMovementState(playerMovementState);

        if (!IsGrounded() && characterController.velocity.y >= 0)
        {
            leonState.SetPlayerMovementState(PlayerMovementState.Jumping);
        }
        else if (!IsGrounded() && characterController.velocity.y < 0)
        {
            leonState.SetPlayerMovementState(PlayerMovementState.Falling);
        }
    }

    private void HandleLateralMovement()
    {
        bool isSprinting = leonState.currentPlayerMovementState == PlayerMovementState.Sprinting;
        
        float lateralAccelration = isSprinting ? sprintAccleration : runAcceleration;
        float clampLateralMagnitude = isSprinting ? sprintSpeed : runSpeed;

        Vector3 cameraForwardXZ = new Vector3(cam.transform.forward.x, 0f, cam.transform.forward.z).normalized;

        Vector3 cameraRightXZ = new Vector3(cam.transform.right.x, 0f, cam.transform.right.z).normalized;

        Vector3 movementDirection = cameraRightXZ * leonInputs.MovementInput.x + cameraForwardXZ * leonInputs.MovementInput.y;

        horizontalVelocity += movementDirection * lateralAccelration * Time.deltaTime;

        if (horizontalVelocity.magnitude > 0f)
        {
            Vector3 currentDrag = horizontalVelocity.normalized * drag * Time.deltaTime;

            horizontalVelocity =
                (horizontalVelocity.magnitude > currentDrag.magnitude) ? horizontalVelocity - currentDrag : Vector3.zero;
        }

        horizontalVelocity = Vector3.ClampMagnitude(horizontalVelocity, clampLateralMagnitude);

        verticalVelocity += gravity * Time.deltaTime;

        if (IsGrounded() && verticalVelocity < 0)
        {
            verticalVelocity = -antiBug;
        }

        Vector3 finalVelocity = horizontalVelocity;
        finalVelocity.y = verticalVelocity;

        characterController.Move(finalVelocity * Time.deltaTime);

        finalVel = finalVelocity;
//        Debug.Log(finalVel.magnitude);

        if (finalVel.magnitude > 9.5f)
        {
            playerIsSprinting = true;
        }
        else playerIsSprinting = false;
    }

    void LateUpdate()
    {
        UpdateCameraRotation();
    }

    private void UpdateCameraRotation()
    {
        cameraRotation.x += lookSenH * leonInputs.LookInput.x;
        cameraRotation.y = Mathf.Clamp(cameraRotation.y - lookSenV * leonInputs.LookInput.y, -lookMinLimitV, lookMaxLimitV);

        playerTargetRotation.x += transform.eulerAngles.x + lookSenH * leonInputs.LookInput.x;

        bool isIdling = leonState.currentPlayerMovementState == PlayerMovementState.Idling;
        IsRotatingToTarget = rotatingToTargetTime > 0;
        

        if (!isIdling)
        {
            RotatePlayerToTarget();
        }

        UpdateIdleRotation(rotationTolerance);

        cam.transform.rotation = Quaternion.Euler(cameraRotation.y, cameraRotation.x, 0f);
        // Debug.Log(_cameraRotation.x);
        // Debug.Log(_camera.transform.rotation);

        Vector3 camForwardProjectionXZ = new Vector3(cam.transform.forward.x, 0f, cam.transform.forward.z).normalized;
        Vector3 crossProduct = Vector3.Cross(transform.forward, camForwardProjectionXZ);
        float sign = Mathf.Sign(Vector3.Dot(crossProduct, transform.up));
        RotationMismatch = sign * Vector3.Angle(transform.forward, camForwardProjectionXZ);
    }

    private void UpdateIdleRotation(float rotationTolerance)
    {
        if (Mathf.Abs(RotationMismatch) > rotationTolerance || IsRotatingToTarget)
        {
            if (Mathf.Abs(RotationMismatch) > rotationTolerance)
            {
                rotatingToTargetTime = rotationTargetTime;
                isRoatingClockWise = RotationMismatch > rotationTolerance;
            }
            rotatingToTargetTime -= Time.deltaTime;

            if (isRoatingClockWise && RotationMismatch > 0f || !isRoatingClockWise && RotationMismatch < 0f)
            {
                RotatePlayerToTarget();
            }   
        }
    }

    private void RotatePlayerToTarget()
    {
        Quaternion targetRotationX = Quaternion.Euler(0f, playerTargetRotation.x, 0f);
        transform.rotation = Quaternion.Lerp(transform.rotation, targetRotationX, playerModelRotationSpeed * Time.deltaTime);
    }

    private bool IsMovingLaterally()
    {
        Vector3 lateralVelocity = new Vector3(characterController.velocity.x, 0f, characterController.velocity.z);

        return lateralVelocity.magnitude > movingThreshlod;
    }

    private bool IsGrounded()
    {
        bool grounded = leonState.InGroundedState() ? IsGroundedWhileGrounded() : IsGroundedWhileInAir();

        return grounded;
    }

    private bool IsGroundedWhileGrounded()
    {
        Vector3 spherePosition = new Vector3(transform.position.x, transform.position.y - characterController.radius, transform.position.z);

        bool grounded = Physics.CheckSphere(spherePosition, characterController.radius, groundLayer, QueryTriggerInteraction.Ignore);

        return grounded;
    }

    private bool IsGroundedWhileInAir()
    {
        return characterController.isGrounded;
    }

    private void HandleFootsteps()
    {
        if (leonInputs.MovementInput.magnitude < 0.1f) return;

        if (!IsGrounded())
        {
            footstepTimer = 0f;
            return;
        }

        float speed = horizontalVelocity.magnitude;

        if (speed < movingThreshlod)
        {
            footstepTimer = 0f;
            return;
        }

        bool isSprinting =
            leonState.currentPlayerMovementState == PlayerMovementState.Sprinting;

        footstepTimer -= Time.deltaTime;

        if (footstepTimer <= 0f)
        {
            if (isSprinting)
            {
                audioSource.PlayOneShot(runAudio);
                footstepTimer = runStepInterval;
            }
            else
            {
                audioSource.PlayOneShot(walkAudio);
                footstepTimer = walkStepInterval;
            }
        }
    }
}