using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInputs : MonoBehaviour, PlayerControls.IPlayerActions
{
    [SerializeField] private bool holdToSprint = true;
    [SerializeField] private bool holdToAim = true;

    public bool sprintToggleOn { get; private set; }
    public bool aimToggleOn { get; private set; }
    public bool jumpPressed { get; private set; }
    public bool attackPressed { get; private set; }
    public PlayerControls playerControls { get; private set; }
    public Vector2 MovementInput;
    public Vector2 LookInput;

    void OnEnable()
    {
        playerControls = new PlayerControls();

        playerControls.Enable();

        playerControls.Player.Enable();
        playerControls.UI.Disable();

        playerControls.Player.SetCallbacks(this);
    }

    void OnDisable()
    {
        if (playerControls != null)
        {
            playerControls.Player.Disable();
            playerControls.UI.Disable();

            playerControls.Player.RemoveCallbacks(this);
        }
    }

    void LateUpdate()
    {
        jumpPressed = false;
    }

    public void OnMove(InputAction.CallbackContext context)
    {
        MovementInput = context.ReadValue<Vector2>();
    }

    public void OnAttack(InputAction.CallbackContext context)
    {
        if (context.performed) attackPressed = true;
        else if (context.canceled) attackPressed = false;
    }

    public void OnCrouch(InputAction.CallbackContext context)
    {
       
    }

    public void OnInteract(InputAction.CallbackContext context)
    {
        
    }

    public void OnJump(InputAction.CallbackContext context)
    {
       if (!context.performed) return;

       jumpPressed = true;
    }

    public void OnLook(InputAction.CallbackContext context)
    {
        LookInput = context.ReadValue<Vector2>();
    }

    public void OnNext(InputAction.CallbackContext context)
    {
        
    }

    public void OnPrevious(InputAction.CallbackContext context)
    {
       
    }

    public void OnSprint(InputAction.CallbackContext context)
    {
       if (context.performed)
        {
            sprintToggleOn = holdToSprint || !sprintToggleOn;
        }
        else if (context.canceled)
        {
            sprintToggleOn = !holdToSprint && sprintToggleOn;
        }
    }

    public void OnAim(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            aimToggleOn = holdToAim || !aimToggleOn;
        }
        else if (context.canceled)
        {
            aimToggleOn = !holdToAim && aimToggleOn;
        }
    }
}
