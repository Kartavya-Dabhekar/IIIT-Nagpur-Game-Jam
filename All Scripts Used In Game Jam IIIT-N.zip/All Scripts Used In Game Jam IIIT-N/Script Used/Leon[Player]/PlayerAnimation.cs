using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using TMPro;
using Unity.Mathematics;

public class PlayerAnimation : MonoBehaviour
{
    [Header("Animator Swap")]
    public Animator leonAnim;
    public Animator drakeAnim;
    public GameObject leonObj;
    public GameObject drakeObj;
    public bool changeAnim;
    public bool backToNormal;
    public CharacterController characterController;
    public Image switcher;
    public Image interpreter;
    public TMP_Text switcherText;
    public TMP_Text interText;
    public GameObject flame;
    public Transform flamePoint;

    [SerializeField] private Animator animator;
    [SerializeField] private float locomotionTime = 0.02f;
    [SerializeField] private float resetLayer = 5.5f;
    [SerializeField] private float animTransitionTime = 0f;
    [SerializeField] private float imageFillTime = 0.3f;
    [SerializeField] private float imageLoseTime = 0.3f;

    private PlayerInputs leonInputs;
    private PlayerState leonState;
    private PlayerController leonController;
    private Vector3 currentBlendState = Vector3.zero;
    private bool canChange;

    private static int InputXHash = Animator.StringToHash("inputX");
    private static int InputYHash = Animator.StringToHash("inputY");
    private static int inputMagnitude = Animator.StringToHash("inputMagnitude");
    private static  int isGroundedHash = Animator.StringToHash("isGrounded");
    private static  int isJumpingHash = Animator.StringToHash("isJumping");
    private static  int isFallingHash = Animator.StringToHash("isFalling");
    private static  int isIdlingHash = Animator.StringToHash("isIdling");
    private static  int isRotatingToTargetHash = Animator.StringToHash("isRotatingTotarget");
    private static  int RotationMismatchHash = Animator.StringToHash("rotationMismatch");

    void Awake()
    {
        leonInputs = GetComponent<PlayerInputs>();
        leonState = GetComponent<PlayerState>();
        leonController = GetComponent<PlayerController>();
        animator = leonAnim;
        //animator_2 = drakeAnim;
        leonObj.SetActive(true);
        drakeObj.SetActive(false);
        canChange = true;
    }

    void Update()
    {
        animTransitionTime += Time.deltaTime;

    if (canChange)
    {
        switcher.fillAmount = Mathf.Clamp01(animTransitionTime * imageFillTime);

        int progress = Mathf.RoundToInt(switcher.fillAmount * 100f);

        if (switcherText != null)
        {
            switcherText.text = progress + "%";
        }

        if (switcher.fillAmount >= 1f)
        {
            switcher.fillAmount = 1f;
            canChange = false;
        }
    }

    UpdateAnimationState();

    bool grounded = characterController.isGrounded;
    bool isImageFilled = switcher.fillAmount >= 1f;


    if (Keyboard.current.pKey.wasPressedThisFrame &&
        !changeAnim &&
        grounded &&
        isImageFilled)
    {
        GameObject _flame = Instantiate(flame, flamePoint.position, quaternion.identity);

        Destroy(_flame, 1f);
        interpreter.fillAmount = 1f;
        switcher.fillAmount = 0f;

        animTransitionTime = 0f;

        leonObj.SetActive(false);
        drakeObj.SetActive(true);

        animator = drakeAnim;
        changeAnim = true;

        Debug.Log("Changed to Drake");
    }

    else if (backToNormal)
    {

        GameObject _flame = Instantiate(flame, flamePoint.position, quaternion.identity);

        Destroy(_flame, 1f);
        canChange = true;

        switcher.fillAmount = 0f;
        animTransitionTime = 0f;

        drakeObj.SetActive(false);

        leonObj.SetActive(true);

        animator = leonAnim;
        changeAnim = false;
        backToNormal = false;

        Debug.Log("Changed to Leon");
    }

    if (changeAnim)
    {
        interpreter.fillAmount -= imageLoseTime * Time.deltaTime;

        int progress = Mathf.RoundToInt(interpreter.fillAmount * 100f);

        if (interText != null)
        {
            interText.text = progress + "%";
        }

        if (interpreter.fillAmount <= 0f)
        {
            interpreter.fillAmount = 0f;
            backToNormal = true;
        }
    }

    }

    private void UpdateAnimationState()
    {
        bool isIdling = leonState.currentPlayerMovementState == PlayerMovementState.Idling;
        bool isRunning = leonState.currentPlayerMovementState == PlayerMovementState.Running;
        bool isSprinting = leonState.currentPlayerMovementState == PlayerMovementState.Sprinting;
        bool isJumping = leonState.currentPlayerMovementState == PlayerMovementState.Jumping;
        bool isFalling = leonState.currentPlayerMovementState == PlayerMovementState.Falling;
        bool isGrounded = leonState.InGroundedState();

        Vector2 moveInput = isSprinting ? leonInputs.MovementInput * 1.5f : leonInputs.MovementInput;
        currentBlendState = Vector3.Lerp(currentBlendState, moveInput, locomotionTime);

        animator.SetBool(isGroundedHash, isGrounded);
        animator.SetBool(isFallingHash, isFalling);
        animator.SetBool(isJumpingHash, isJumping);
        animator.SetBool(isIdlingHash, isIdling);
        animator.SetBool(isRotatingToTargetHash, leonController.IsRotatingToTarget);
        animator.SetFloat(RotationMismatchHash, leonController.RotationMismatch);

        animator.SetFloat(InputXHash, moveInput.x, 0.05f, Time.deltaTime);
        animator.SetFloat(InputYHash, moveInput.y, 0.05f, Time.deltaTime);
        animator.SetFloat(inputMagnitude, currentBlendState.magnitude);
    }
}
