using UnityEngine;
using UnityEngine.Animations.Rigging;

public class PistolController : MonoBehaviour
{
    [Header("Input Section")]
    [SerializeField] private PlayerInputs leonInputs;

    [Header("References")]
    [SerializeField] private Camera cam;
    [SerializeField] private Animator animator;
    [SerializeField] private TwoBoneIKConstraint weaponIK;

    [Header("Animator Tab")]
    [SerializeField] private int pistolLayer = 1;
    [SerializeField] private float layerBlendSpeed = 8f;

    [Header("Aim Setup")]
    [SerializeField] private LayerMask aimLayers;
    [SerializeField] private float maxAimDistance = 200f;

    [Header("Pistol Info")]
    [SerializeField] private Transform muzzlePoint;
    [SerializeField] private float damage = 25f;
    [SerializeField] private float fireRate = 0.25f;
    [SerializeField] private float range = 200f;

    [Header("Particle effects Info")]
    [SerializeField] private ParticleSystem muzzleFlash;
    [SerializeField] private GameObject hitEffect;

    public Vector3 AimPoint { get; private set; }

    private float nextFireTime;

    private static readonly int AimingHash = Animator.StringToHash("Aiming");

    private static readonly int FireHash = Animator.StringToHash("Fire");

    private static readonly int ReloadingHash = Animator.StringToHash("Reloading");

    private void Awake()
    {
        animator = GetComponent<Animator>();
        cam = Camera.main;
        leonInputs = GetComponent<PlayerInputs>();
    }

    private void Update()
    {
        UpdateAimPoint();
        UpdatePistolLayer();
        UpdateAiming();
        HandleFire();
    }

    private void UpdatePistolLayer()
    {
        float targetWeight = leonInputs.aimToggleOn ? 1f : 0f;
        float currentWeight = animator.GetLayerWeight(pistolLayer);
        float newWeight = Mathf.MoveTowards(currentWeight, targetWeight, layerBlendSpeed * Time.deltaTime);

        animator.SetLayerWeight(pistolLayer, newWeight);

        if (weaponIK != null)
        {
            weaponIK.weight = newWeight;
        }
    }

    private void UpdateAiming()
    {
        animator.SetBool(AimingHash, leonInputs.aimToggleOn);
    }

    private void UpdateAimPoint()
    {

        Vector2 screenCenter = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);
        Ray ray = cam.ScreenPointToRay(screenCenter);

        if (Physics.Raycast(ray, out RaycastHit hit, maxAimDistance, aimLayers, QueryTriggerInteraction.Ignore))
        {
            AimPoint = hit.point;
        }
        else
        {
            AimPoint = ray.origin + ray.direction * maxAimDistance;
        }

        Debug.DrawRay( ray.origin, ray.direction * maxAimDistance, Color.green);
    }

    private void HandleFire()
    {
        Fire();
    }

    private void Fire()
    {
        nextFireTime = Time.time + fireRate;

        animator.SetTrigger(FireHash);
        muzzleFlash.Play();

        Vector3 direction = (AimPoint - muzzlePoint.position).normalized;

        if (Physics.Raycast(muzzlePoint.position, direction, out RaycastHit hit, range, aimLayers, QueryTriggerInteraction.Ignore))
        {
            Debug.DrawLine(muzzlePoint.position, hit.point, Color.red, 1f);
            Debug.Log("Pistol hit: " +hit.collider.name);

            if (hitEffect != null)
            {
                Instantiate(hitEffect, hit.point, Quaternion.LookRotation(hit.normal));
            }
        }
    }

    public void StartReload()
    {
        animator.SetBool(ReloadingHash, true);
    }

    public void StopReload()
    {
        animator.SetBool(ReloadingHash,false);
    }
}
