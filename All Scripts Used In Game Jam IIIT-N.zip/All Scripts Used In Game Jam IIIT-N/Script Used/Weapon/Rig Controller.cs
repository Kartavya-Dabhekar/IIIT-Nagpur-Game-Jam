using UnityEngine;
using UnityEngine.Animations.Rigging;

public class RigController : MonoBehaviour
{
    public TwoBoneIKConstraint leftHandIK;
    public TwoBoneIKConstraint rightHandIK;
    public PlayerInputs leonInputs;

    public bool weaponFore;
    public GameObject pistol;
    public Animator animator;
    public PlayerController leonController;

    [Header("Meshes Settings Tab")]
    public MeshRenderer[] pistolMeshes;

    [Header("Fire Hold Settings Tab")]
    [SerializeField] private float holdTime = 0.2f;

    private float holdTimer = 0f;

    void Update()
    {
        if (leonInputs.attackPressed && !leonController.playerIsSprinting)
        {
            holdTimer += Time.deltaTime;

            if (holdTimer >= holdTime)
            {
                weaponFore = true;
                //pistol.SetActive(true);

                foreach (MeshRenderer pistol in pistolMeshes)
                {
                    pistol.enabled = true;
                }
            }
        }
        else
        {
            holdTimer = 0f;

            weaponFore = false;
            //pistol.SetActive(false);

            foreach (MeshRenderer pistol in pistolMeshes)
            {
                pistol.enabled = false;
            }
        }

        animator.SetBool("Fire", weaponFore);

        float targetWeight = weaponFore ? 1f : 0f;

        leftHandIK.weight = Mathf.Lerp(leftHandIK.weight, targetWeight, Time.deltaTime * 10f);

        rightHandIK.weight = Mathf.Lerp(rightHandIK.weight, targetWeight, Time.deltaTime * 10f);
    }
}
